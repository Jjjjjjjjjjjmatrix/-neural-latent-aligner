## Objectif
<!-- Quel probleme cette PR resout-elle ? Lien vers le ticket. -->

## Changements
-

## Impact sur les resultats
- [ ] Aucun (refactor / doc / CI)
- [ ] Metriques modifiees -> joindre le run de comparaison

## Checklist
- [ ] `ruff check` et `pytest` passent
- [ ] Aucune donnee patient / PHI ajoutee au depot
- [ ] Config et seed documentes pour la reproductibilite
