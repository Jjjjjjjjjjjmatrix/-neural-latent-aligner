# Neural Latent Aligner (NLA)

Implementation de reference de l'alignement inter-essais pour l'apprentissage de
representations de donnees neurales naturalistes (ECoG), d'apres *Neural Latent Aligner:
Cross-trial Alignment for Learning Representations of Complex, Naturalistic Neural Data*
(Cho, Chang, Anumanchipalli).

## Idee

Deux essais du meme stimulus produisent des signaux neuraux qui different par le bruit **et**
par le decalage temporel. NLA apprend simultanement (i) un espace latent qui reconstruit le
signal et (ii) un alignement temporel entre essais, de sorte que le **facteur de contenu**
`c^x` ne retienne que ce qui est invariant d'un essai a l'autre.

$$\mathcal{L} = \underbrace{\mathbb{E}\|x-\hat{x}\|^2}_{\text{reconstruction}}
+ \lambda \underbrace{\|c^{x} - g_\phi(s^{x'\to x})\|^2}_{\text{calibration}}
+ \beta\, \Omega(A)$$

| Symbole | Code | Forme |
|---|---|---|
| `s^x` = f_theta(x) | `ConvEncoder` | (B, d, T') |
| `x_hat` = h_psi(s^x) | `ConvDecoder` | (B, E, T) |
| `c^x` = g_phi(s^x) | `ContentHead` | (B, k, T'), k < d |
| `A`, `s^{x'->x}` | `TrialWarpingModule` | (B, T', T') |

## Installation

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev,viz]"
```

## Donnees

Format attendu : un `.npz` avec `trials` (N, E, T) float32 z-score et `labels` (N,)
identifiant le stimulus. Chaque stimulus doit apparaitre au moins **deux fois**
(sinon pas de paire a aligner).

```
data/processed/ecog_trials.npz   # non versionne, voir .gitignore
```

## Entrainement

```bash
nla-train --config configs/default.yaml --out checkpoints/
```

Extraction des representations pour une tache aval :

```python
from nla import NeuralLatentAligner
import torch

model = NeuralLatentAligner(n_electrodes=256)
model.load_state_dict(torch.load("checkpoints/last.pt"))
c = model.extract_content(x)   # (B, k, T')
```

## Structure

```
src/nla/
├── models/
│   ├── encoder.py   # f_theta, h_psi, g_phi
│   ├── twm.py       # Trial Warping Module + Omega(A)
│   └── nla.py       # modele complet
├── data/            # dataset de paires d'essais
├── losses.py        # L_rec, L_cal, total
└── train.py         # boucle d'entrainement
```

## Conformite

Donnees ECoG humaines : aucune donnee identifiante ne doit etre commitee.
Voir `CONTRIBUTING.md`. Usage recherche uniquement, non destine au diagnostic clinique.

## Licence

MIT — voir `LICENSE`.
