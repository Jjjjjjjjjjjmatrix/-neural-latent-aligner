"""Neural Latent Aligner (NLA) - alignement inter-essais pour donnees neurales."""

from .models.nla import NeuralLatentAligner
from .models.twm import TrialWarpingModule

__all__ = ["NeuralLatentAligner", "TrialWarpingModule"]
__version__ = "0.1.0"
