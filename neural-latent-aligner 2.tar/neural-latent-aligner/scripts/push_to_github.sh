#!/usr/bin/env bash
# Usage : ./scripts/push_to_github.sh <org> <repo>
set -euo pipefail
ORG="${1:?organisation manquante}"
REPO="${2:?nom du depot manquant}"

git init -b main
git add .
git commit -m "feat: initial NLA scaffold"
git remote add origin "https://github.com/${ORG}/${REPO}.git"
git push -u origin main

echo "Pense a activer : branch protection sur main, required status checks (CI), et CODEOWNERS."
