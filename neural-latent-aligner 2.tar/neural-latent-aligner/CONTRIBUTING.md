# Contribuer

## Mise en place
```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev,viz]"
pre-commit install
```

## Regles
- Branches : `feat/...`, `fix/...`, `exp/...` ; commits en [Conventional Commits](https://www.conventionalcommits.org).
- `main` est protegee : PR + 1 revue + CI verte obligatoires.
- Toute experience doit etre reproductible depuis un fichier de `configs/` versionne.
- **Aucune donnee patient (PHI) ne doit entrer dans le depot.** Les donnees restent sur le stockage securise de l'equipe ; seuls les chemins sont configures.

## Avant de pousser
```bash
ruff check src tests --fix
pytest -q
```
